package com.onezero.zeromanage.controller;

import com.onezero.zeromanage.dto.Role;
import com.onezero.zeromanage.service.RoleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;

@Controller
public class RoleController {
    @Autowired
    private RoleService roleService;
    //selectAll
    @RequestMapping(value = "/role")
    @ResponseBody
    public List<Role> getRoles(){
        List<Role> Roles = roleService.selectAll();
        return Roles;
    }
    //selectRoleById
    @RequestMapping(value="/getRole",method = RequestMethod.POST)
    @ResponseBody
    public Role getRoleById(String id){
        Role selectRole = roleService.selectById(id);
        return selectRole;
    }
    //InsertRole
    @RequestMapping(value = "/addUpdateRole",method = RequestMethod.POST)
    @ResponseBody
    public String addRole(@RequestParam(value = "id",required=false)String id, Role role){
        boolean addStt = false;
        boolean updStt = false;
        if(id==null || "".equals(id)){
            addStt =  roleService.insertRole(role);
            if(addStt){
                return "addSuccess";
            }else{
                return "addfail";
            }
        }else{
            updStt = roleService.updateRole(role);
            if(updStt){
                return "updSuccess";
            }else{
                return "updfail";
            }
        }
    }
    //deleteRole
    @RequestMapping(value="/deleteRole",method = RequestMethod.POST)
    @ResponseBody
    public String deleteRole(String id){
        boolean delStt = roleService.deleteRole(id);
        if(delStt){
            return "delSuccess";
        }else{
            return "delfail";
        }
    }
}
