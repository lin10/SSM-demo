package com.onezero.zeromanage.service.impl;

import com.onezero.zeromanage.dto.Role;
import com.onezero.zeromanage.mapper.RoleMapper;
import com.onezero.zeromanage.service.RoleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RoleServiceImpl implements RoleService {

    @Autowired
    private RoleMapper roleMapper;
    @Override
    public List<Role> selectAll(){
        return roleMapper.selectAll();
    }

    //select
    @Override
    public Role selectById(String id) {
        return roleMapper.selectById(id);
    }
    //insertRole
    public boolean insertRole(Role role){
        boolean addResult = roleMapper.addRole(role);
        return addResult;
    }
    //updateRole
    public boolean updateRole(Role role){
        boolean updResult = roleMapper.updateRole(role);
        return updResult;
    }
    //deleteRole
    public boolean deleteRole(String id){
        boolean delResult = roleMapper.deleteRole(id);
        return delResult;
    }

}
