package com.onezero.zeromanage.service;
import com.onezero.zeromanage.dto.Role;
import java.util.List;

public interface RoleService {
   //List
    List<Role> selectAll();
    //select
    Role selectById(String id);
    //insertRole
    boolean insertRole(Role role);
    //updateRole
    boolean updateRole(Role role);
    //deleteRole
    boolean deleteRole(String id);
}
