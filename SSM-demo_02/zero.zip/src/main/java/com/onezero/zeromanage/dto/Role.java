package com.onezero.zeromanage.dto;


public class Role {
    private String id;
    private String roleName;
    private String status;

    public Role(){
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getId() {
        return id;
    }

    public String getRoleName() {
        return roleName;
    }

    public String getStatus() {
        return status;
    }
}
