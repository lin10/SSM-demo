package com.onezero.zeromanage.mapper;

import com.onezero.zeromanage.dto.Role;

import java.util.List;

public interface RoleMapper {
    List<Role> selectAll();
    //selectById
    Role selectById(String id);
    //insertRole
    boolean addRole(Role role);
    //updateRole
    boolean updateRole(Role role);
    //deleteRole
    boolean deleteRole(String id);
}
